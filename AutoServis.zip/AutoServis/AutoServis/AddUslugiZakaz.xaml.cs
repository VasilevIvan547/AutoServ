﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace AutoServis
{
    /// <summary>
    /// Логика взаимодействия для AddUslugiZakaz.xaml
    /// </summary>
    /// 
    public partial class AddUslugiZakaz : Window
    {
        public static int KodKlient = 0;
        private AutoservisEntities db;

        public static Клиент SelectedClient { get; set; }
        public AddUslugiZakaz()
        {
            InitializeComponent();

            CmbKlienta.SelectedValuePath = "КодКлиента";
            CmbKlienta.DisplayMemberPath = "ФИО";
            CmbKlienta.ItemsSource = OdbConnectHelper.entObj.Клиент.ToList();

            CmbMexanik.SelectedValuePath = "КодМастера";
            CmbMexanik.DisplayMemberPath = "ФИО";
            CmbMexanik.ItemsSource = OdbConnectHelper.entObj.Мастер.ToList();

            CmbUsluga.SelectedValuePath = "КодУслуги";
            CmbUsluga.DisplayMemberPath = "Название";
            CmbUsluga.ItemsSource = OdbConnectHelper.entObj.Услуга.ToList();

            CmbAuto.SelectedValuePath = "КодАвтомобиля";
            CmbAuto.DisplayMemberPath = "РегистрационныйЗнак";
            
         
        }
    private void CmbStoim_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var uslug1 = CmbUsluga.SelectedItem as Услуга;
            CmbStoim.Text = uslug1.Цена.ToString();
            Convert.ToInt32(CmbStoim.Text);


            int sum = Int32.Parse(CmbStoim.Text) - Int32.Parse(Predoplata.Text);
            OStoim.Text = sum.ToString();
            Convert.ToInt32(OStoim.Text);
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            DateTime dt = Convert.ToDateTime(Date.Text);
           
            Заказ work_schedule = new Заказ()
            {
                
                //date = DateTime.Today,
                Клиент = CmbKlienta.SelectedItem as Клиент,
                Предоплата = Int32.Parse(Predoplata.Text),
                Автомобиль = CmbAuto.SelectedItem as Автомобиль,
                Дата = dt,
                Стоимость = Int32.Parse(OStoim.Text),
            };

                УслугаЗаказа work_schedule1 = new УслугаЗаказа()
                {
                    //Дата = Convert.ToDateTime(Date),
                    Мастер = CmbMexanik.SelectedItem as Мастер,
                    Услуга = CmbUsluga.SelectedItem as Услуга,
                    Стоимость = Int32.Parse(CmbStoim.Text),
                    КодКлиента = KodKlient,
                };

                    OdbConnectHelper.entObj.УслугаЗаказа.Add(work_schedule1);
                    OdbConnectHelper.entObj.Заказ.Add(work_schedule);
                    OdbConnectHelper.entObj.SaveChanges();
            OrderingService ordering = new OrderingService();
            db = new AutoservisEntities();
            db.УслугаЗаказа.Load();
    
            ordering.IOrderingService.ItemsSource = db.УслугаЗаказа.Local.ToBindingList();
            db.Заказ.Load();
            ordering.IOrder.ItemsSource = db.Заказ.Local.ToBindingList();
            //if (CmbKlienta.Text.Length == 0 || Predoplata.Text.Length == 0 || CmbAuto.Text.Length == 0 || OStoim.Text.Length == 0 || CmbMexanik.Text.Length == 0 || CmbUsluga.Text.Length == 0 || CmbStoim.Text.Length == 0 || CopyCmbKlienta.Text.Length == 0)
            //{
            //    if (MessageBox.Show("Не все данные заполненны хотите ли вы продолжить?", "Выход", MessageBoxButton.YesNo) == MessageBoxResult.Yes) 
            //    {

            //        AddUslugiZakaz a = new AddUslugiZakaz();
            //        a.Close();

            //    }
            //    else { MessageBox.Show("данные не заполнены"); }
            //}




        }

        private void CmbUsluga_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            
        }

    
        private void Ss_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void CopyCmbKlienta_TextChanged(object sender, TextChangedEventArgs e)
        {
           
        }

        private void CmbKlienta_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var kl = CmbKlienta.SelectedItem as Клиент;
            CopyCmbKlienta.Text = kl.КодКлиента.ToString();
            Convert.ToUInt32(CopyCmbKlienta.Text);




        }

        private void Predoplata_TextChanged(object sender, TextChangedEventArgs e)
        {
            if(OStoim != null)
            {
                int predoplata = Convert.ToInt32(Predoplata.Text);
                int ostoim = Convert.ToInt32(OStoim.Text);
                OStoim.Text = Convert.ToString(ostoim - predoplata);
            }
           
        }

        private void OStoim_TextChanged(object sender, TextChangedEventArgs e)
        {

           
        }


        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            
        }

        private void CmbKlienta_SelectionChanged_1(object sender, SelectionChangedEventArgs e)
        {
            var klient = CmbKlienta.SelectedItem as Клиент;
            CmbAuto.ItemsSource = OdbConnectHelper.entObj.Автомобиль.Where(p => p.ККодКлиента == klient.КодКлиента).ToList();
            CmbAuto.SelectedIndex = 0;
            KodKlient = klient.КодКлиента;

        }
    }
}
