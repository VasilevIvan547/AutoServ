﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Data.Entity;

namespace AutoServis
{
    public partial class Auto : Window
    {
        AutoservisEntities db;
        public Auto()
        {
            InitializeComponent(); db = new AutoservisEntities();
            db.Автомобиль.Load();
            IAuto.Items.Clear();
            IAuto.ItemsSource = db.Автомобиль.Local.ToBindingList();
            db.Клиент.Load();
            ICustomers.Items.Clear();
            ICustomers.ItemsSource = db.Клиент.Local.ToBindingList();
        }
        private void AutoGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        { }
        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            db = new AutoservisEntities();
            db.Автомобиль.Where(i => i.МаркаАвтомобиля.ToLower().Contains(marka.Text.ToLower())).Load();
            IAuto.ItemsSource = db.Автомобиль.Local.ToBindingList();
            if (marka.Text.Length == 0) db.Автомобиль.Load();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            db.SaveChanges();

        }
        private void TextBoxznak_TextChanged(object sender, TextChangedEventArgs e)
        {
            db = new AutoservisEntities();
            db.Автомобиль.Where(i => i.РегистрационныйЗнак.ToLower().Contains(znak_Copy.Text.ToLower())).Load();
            IAuto.ItemsSource = db.Автомобиль.Local.ToBindingList();
            if (znak_Copy.Text.Length == 0) db.Автомобиль.Load();

        }

        private void Button_Del_Klient(object sender, RoutedEventArgs e)
        { if (ICustomers.SelectedItems.Count > 0)
            { for (int i = 0; i < ICustomers.SelectedItems.Count; i++)
                { Клиент cust = ICustomers.SelectedItems[i] as Клиент;
                    if (cust != null)
                    {
                        db.Клиент.Remove(cust);
                    } } } db.SaveChanges(); }
        private void Button_Del_Auto(object sender, RoutedEventArgs e)
        {if (IAuto.SelectedItems.Count > 0)
            { for (int i = 0; i < IAuto.SelectedItems.Count; i++)
                {Автомобиль avt = IAuto.SelectedItems[i] as Автомобиль;
                    if (avt != null)
                    {  db.Автомобиль.Remove(avt);} } } db.SaveChanges(); }}}
