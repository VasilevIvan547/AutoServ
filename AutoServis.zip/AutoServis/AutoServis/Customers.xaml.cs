﻿using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Data.Entity;

namespace AutoServis
{
    public partial class Customers : Window
    {
        AutoservisEntities db;
        public Customers()
        {
            InitializeComponent();
            db = new AutoservisEntities();
            db.Клиент.Load();
            ICustomers.Items.Clear();
            ICustomers.ItemsSource = db.Клиент.Local.ToBindingList();
        }
        private void AutoGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            db.SaveChanges();
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            db = new AutoservisEntities();
            db.Клиент.Where(i => i.ФИО.ToLower().Contains(FIO.Text.ToLower())).Load();
            ICustomers.ItemsSource = db.Клиент.Local.ToBindingList();
            if (FIO.Text.Length == 0) db.Клиент.Load(); 
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            if (ICustomers.SelectedItems.Count > 0)
            {
                for (int i = 0; i < ICustomers.SelectedItems.Count; i++)
                {
                    Клиент cust = ICustomers.SelectedItems[i] as Клиент;
                    if (cust != null)
                    {
                        db.Клиент.Remove(cust);
                    }
                }
            }
            db.SaveChanges();
        }
    }
}
