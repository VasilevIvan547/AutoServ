﻿using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Data.Entity;

namespace AutoServis
{
    public partial class Directory_SpareParts : Window
    {
        AutoservisEntities db;
        public Directory_SpareParts()
        {
            InitializeComponent();
            db = new AutoservisEntities();
            db.Услуга.Load();
            IDirectory_SpareParts.Items.Clear();
            IDirectory_SpareParts.ItemsSource = db.Услуга.Local.ToBindingList();
        }
        private void AutoGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {  db.SaveChanges(); }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            db = new AutoservisEntities();
            db.Услуга.Where(i => i.Название.ToLower().Contains(zp.Text.ToLower())).Load();
            IDirectory_SpareParts.ItemsSource = db.Услуга.Local.ToBindingList();
            if (zp.Text.Length == 0) db.Услуга.Load();
            //создать поиск выбранной стоимости    >  < ==  числу x 
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            if (IDirectory_SpareParts.SelectedItems.Count > 0)
            {
                for (int i = 0; i < IDirectory_SpareParts.SelectedItems.Count; i++)
                {
                    Услуга z = IDirectory_SpareParts.SelectedItems[i] as Услуга;
                    if (z != null)
                    {
                        db.Услуга.Remove(z);
                    }
                }
            }
            db.SaveChanges();
        }
    }
}
