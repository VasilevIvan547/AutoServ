﻿using System;
using System.Linq;
using System.Windows;

namespace AutoServis
{
    public partial class MainWindow : Window
    {
        AutoservisEntities db;
      
        public MainWindow()
        {
            InitializeComponent();
             OdbConnectHelper.entObj = new AutoservisEntities();
        }
        private void BtnReg_Click(object sender, RoutedEventArgs e)
        { Registration reg = new Registration();
            reg.Show();
            Close();  }
        private void BtnLogin_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var userObj = OdbConnectHelper.entObj.Пользователь.FirstOrDefault(
                    x => x.Логин == TxbLogin.Text && x.Пароль == PsbPassword.Password
                    );
                if (userObj == null)
                {
                    MessageBox.Show("Такой пользователь отсутствует!",
                                "Уведомление",
                                MessageBoxButton.OK,
                                MessageBoxImage.Information);
                    Registration reg = new Registration();
                    reg.Show();
                    Close();
                }
                else
                {
                    switch (userObj.КодРоли)
                    {
                        case 1:
                            MessageBox.Show("Здравствуйте, " + userObj.Логин + "!",
                            "Уведомление",
                            MessageBoxButton.OK,
                            MessageBoxImage.Information);
                            OrderingService adm = new OrderingService();
                            adm.Show();
                            Close();
                            break;
                        case 2:
                            MessageBox.Show("Здравствуйте, " + userObj.Логин + "!",
                            "Уведомление",
                            MessageBoxButton.OK,
                            MessageBoxImage.Information);
                            Customers me = new Customers();
                            me.Show();
                            Close();
                            break;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Критический сбор в работе приложения:" + ex.Message.ToString(),
                                "Уведомление",
                                MessageBoxButton.OK,
                                MessageBoxImage.Warning);
            }
        }}}
