﻿using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Data.Entity;

namespace AutoServis
{
    public partial class MasterService : Window
    {
        AutoservisEntities db;
        public MasterService()
        {
            InitializeComponent(); db = new AutoservisEntities();
            db.Мастер.Load();
            IMasterService.Items.Clear();
            IMasterService.ItemsSource = db.Мастер.Local.ToBindingList();
        }
        private void AutoGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        { }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            OrderingService od = new OrderingService();
            Show();
            Close();
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            db = new AutoservisEntities();
            db.Мастер.Where(i => i.ФИО.ToLower().Contains(SearchButton.Text.ToLower())).Load();
            IMasterService.ItemsSource = db.Мастер.Local.ToBindingList();
            if (SearchButton.Text.Length == 0) db.Мастер.Load();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            if (IMasterService.SelectedItems.Count > 0)
            {
                for (int i = 0; i < IMasterService.SelectedItems.Count; i++)
                {
                    Мастер master = IMasterService.SelectedItems[i] as Мастер;
                    if (master != null)
                    {
                        db.Мастер.Remove(master);
                    }
                }
            }
            db.SaveChanges();
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            db.SaveChanges();
        }
    }
}
