﻿using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Data.Entity;


namespace AutoServis
{
    /// <summary>
    /// Логика взаимодействия для OrderingService.xaml
    /// </summary>
    public partial class OrderingService : Window
    {
        AutoservisEntities db;
        public OrderingService()
        {
            InitializeComponent();
            
                db = new AutoservisEntities();
                db.УслугаЗаказа.Load();
                IOrderingService.Items.Clear();
                IOrderingService.ItemsSource = db.УслугаЗаказа.Local.ToBindingList();
                db.Заказ.Load();
                IOrder.Items.Clear();
                IOrder.ItemsSource = db.Заказ.Local.ToBindingList(); 
        }
        private void AutoGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        { }

       
        private void Summa_Click(object sender, RoutedEventArgs e)
        {
            var off = 0;

          //при выборе строк чтобы считалась сумма и если выбрал разные фамиои

            //for (int u = 0; u < IOrder.SelectedItems.Count; u++)
            //{
            //    Заказ f2 = IOrder.SelectedItems[u] as Заказ;
            //    var b = f2.КодКлиента;
                for (int j = 0; j < IOrder.SelectedItems.Count; j++)
                {
                    Заказ f3 = IOrder.SelectedItems[j] as Заказ;

                //if (b == f3.КодКлиента)
                //{
                off += f3.Стоимость.Value;
                ObSumma.Text = (off).ToString() + " рублей";
                //}
                //else MessageBox.Show("gdf");


            }


            //}


        }
      
        private void Predoplata_TextChanged(object sender, TextChangedEventArgs e)
        {  }
        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            //{

            //    for (int i = 0; i < IOrderingService.SelectedItems.Count; i++)
            //    {

            //        УслугаЗаказа f = IOrderingService.SelectedItems[i] as УслугаЗаказа;
            //        if (f.КодУслуги == f.Услуга.КодУслуги)
            //        {


            //            f.Стоимость = f.Услуга.Цена;
            //            hint.Text = f.Стоимость.ToString();
            //            ferz.Text = (f.Стоимость).ToString() + " рублей";
            //            db.SaveChanges();

            //        }
            //        else MessageBox.Show("Ничего");
            //    }
            //}
            //    catch { return; }


            //var a = 0;
            //try
            //{
            //    for (int i = 0; i < IOrderingService.SelectedItems.Count; i++)
            //    {

            //        УслугаЗаказа f = IOrderingService.SelectedItems[i] as УслугаЗаказа;
            //        if (f.НомерЗаказа == f.НомерЗаказа)
            //            a += f.Стоимость.Value;

            //        ferz.Text = a.ToString() + " рублей";
            //        hint.Text = a.ToString();
            //    }
            //}
            //catch { return; }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Customers cs = new Customers();
            cs.Show();

        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            Directory_SpareParts ds = new Directory_SpareParts();
            ds.Show();
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            MasterService ms = new MasterService();
            ms.Show();
        }

        private void Ferz_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void TextBox_TextChanged_1(object sender, TextChangedEventArgs e)
        {
            try
            {

                db = new AutoservisEntities();

              
                db.Заказ.Where(o => o.Клиент.ФИО.ToLower().Contains(SearchNZ.Text.ToLower())).Load();
                IOrder.ItemsSource = db.Заказ.Local.ToBindingList();
                var a = SearchNZ.Text;
                if (SearchNZ.Text.Length == 0)
                    db.Заказ.Load();

                db.УслугаЗаказа.Where(o => o.Клиент.ФИО.ToLower().Contains(SearchNZ.Text.ToLower())).Load();
                IOrderingService.ItemsSource = db.УслугаЗаказа.Local.ToBindingList();
                var b = SearchNZ.Text;
                if (SearchNZ.Text.Length == 0)
                    db.УслугаЗаказа.Load();

            }

            catch
            {
                db.Заказ.Load(); db.УслугаЗаказа.Load();
            }



        }

        private void Button_Click_4(object sender, RoutedEventArgs e)
        {
            AddUslugiZakaz a = new AddUslugiZakaz();
            a.Show();


        }

        private void Button_Click_5(object sender, RoutedEventArgs e)
        {
            Auto aut = new Auto();
            aut.Show();
        }

        private void Button_Click_6(object sender, RoutedEventArgs e)
        {
            if (IOrder.SelectedItems.Count > 0)
            {
                for (int i = 0; i < IOrder.SelectedItems.Count; i++)
                {
                    Заказ cust = IOrder.SelectedItems[i] as Заказ;
                    if (cust != null)
                    {
                        db.Заказ.Remove(cust);
                    }
                }
            }

            if (IOrderingService.SelectedItems.Count > 0)
            {
                for (int i = 0; i < IOrderingService.SelectedItems.Count; i++)
                {
                    УслугаЗаказа cust = IOrderingService.SelectedItems[i] as УслугаЗаказа;
                    if (cust != null)
                    {
                        db.УслугаЗаказа.Remove(cust);
                    }
                }
            }
            db.SaveChanges();
        }

        private void Button_Click_7(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("1. При удалении Заказа  -  данные заказа удаляются в обеих таблицах." +
                "2. Общая сумма рассчитывается = стоимость заказа + стоимость деталей - предоплата");
        }

        private void ObSumma_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void Button_Click_8(object sender, RoutedEventArgs e)
        {
            OrderingService n = new OrderingService();
            n.Show();
            this.Close();

        }

        private void Button_Click_9(object sender, RoutedEventArgs e)
        {
            db.SaveChanges();
            
        }

        private void Button_Click_10(object sender, RoutedEventArgs e)
        {
           
        }
    }
}
