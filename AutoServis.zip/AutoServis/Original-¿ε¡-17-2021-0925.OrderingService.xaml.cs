﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data.Entity;



namespace AutoServis
{
    /// <summary>
    /// Логика взаимодействия для OrderingService.xaml
    /// </summary>
    public partial class OrderingService : Window
    {
        АвтосервисEntities db;
        public OrderingService()
        {
            InitializeComponent();
            db = new АвтосервисEntities();
            db.УслугиЗаказа.Load();
            IOrderingService.Items.Clear();
            IOrderingService.ItemsSource = db.УслугиЗаказа.Local.ToBindingList();
            db.Заказы.Load();
            IOrder.Items.Clear();
            IOrder.ItemsSource = db.Заказы.Local.ToBindingList();
        }
        private void AutoGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
    
        }


        private void Button_Click(object sender, RoutedEventArgs e)
        {
            for (int i = 0; i < IOrderingService.SelectedItems.Count; i++)
            {
                УслугиЗаказа f = IOrderingService.SelectedItems[i] as УслугиЗаказа;
                for (int j = 0; j < IOrder.SelectedItems.Count; j++)
            {

                Заказы f2 = IOrder.SelectedItems[i] as Заказы;
                if (f.НомерЗаказа == f2.КодЗаказа)
                {

                    f2.Стоимость = f.Стоимость  + f2.Стоимость;

                }
                else MessageBox.Show("Ничего");
            }
            
            }



            //Вычисляет стоимость новых установленных запчастей (Стоимость запчасти * количество)
            for (int i = 0; i < IOrderingService.SelectedItems.Count; i++)
            {
              
                УслугиЗаказа f = IOrderingService.SelectedItems[i] as УслугиЗаказа;
                if (f.УстановленныеНовыеЗапчасти == f.СправочникЗапчастей.КодЗапчасти )
                {
                    f.Стоимость = f.СправочникЗапчастей.Стоимость * f.Количество;
                    
                }
                else MessageBox.Show("Ничего");
            }
            db.SaveChanges();
        }

        private void Summa_Click(object sender, RoutedEventArgs e)
        {
            for (int i = 0; i < IOrderingService.SelectedItems.Count; i++)
            {
                УслугиЗаказа f = IOrderingService.SelectedItems[i] as УслугиЗаказа;
                for (int j = 0; j < IOrder.SelectedItems.Count; j++)
                {

                    Заказы f2 = IOrder.SelectedItems[i] as Заказы;
                    
                        Predoplata.Text = f2.Предоплата.ToString();
                       

                    
                }

            }



        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
           
                    foreach (System.Data.DataRowView dr in IOrder.ItemsSource)
                    {
                        MessageBox.Show(dr[0].ToString());
                    }




            
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
          

            for (int i = 0; i < IOrderingService.SelectedItems.Count; i++)
            {
                УслугиЗаказа f = IOrderingService.SelectedItems[i] as УслугиЗаказа;
                for (int j = 0; j < IOrder.SelectedItems.Count; j++)
                {

                    Заказы f2 = IOrder.SelectedItems[i] as Заказы;

                    ObSumma.Text = (f.Стоимость + f2.Стоимость - f2.Предоплата).ToString() ;



                }

            }

        }
    }
}
