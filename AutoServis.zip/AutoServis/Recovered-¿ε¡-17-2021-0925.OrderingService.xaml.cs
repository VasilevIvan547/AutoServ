﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data.Entity;



namespace AutoServis
{
    /// <summary>
    /// Логика взаимодействия для OrderingService.xaml
    /// </summary>
    public partial class OrderingService : Window
    {
        АвтосервисEntities db;
        public OrderingService()
        {
            InitializeComponent();
            db = new АвтосервисEntities();
            db.УслугиЗаказа.Load();
            IOrderingService.Items.Clear();
            IOrderingService.ItemsSource = db.УслугиЗаказа.Local.ToBindingList();
            db.Заказы.Load();
            IOrder.Items.Clear();
            IOrder.ItemsSource = db.Заказы.Local.ToBindingList();
        }
        private void AutoGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
    
        }


        private void Button_Click(object sender, RoutedEventArgs e)
        {
            for (int i = 0; i < IOrderingService.SelectedItems.Count; i++)
            {
                УслугиЗаказа f = IOrderingService.SelectedItems[i] as УслугиЗаказа;
                for (int j = 0; j < IOrder.SelectedItems.Count; j++)
            {

                Заказы f2 = IOrder.SelectedItems[i] as Заказы;
                if (f.НомерЗаказа == f2.КодЗаказа)
                {

                    f2.Стоимость = f.Стоимость  + f2.Стоимость;

                }
                else MessageBox.Show("Ничего");
            }
            
            }



            //Вычисляет стоимость новых установленных запчастей (Стоимость запчасти * количество)
            for (int i = 0; i < IOrderingService.SelectedItems.Count; i++)
            {
              
                УслугиЗаказа f = IOrderingService.SelectedItems[i] as УслугиЗаказа;
                if (f.УстановленныеНовыеЗапчасти == f.СправочникЗапчастей.КодЗапчасти )
                {
                    f.Стоимость = f.СправочникЗапчастей.Стоимость * f.Количество;
                    
                }
                else MessageBox.Show("Ничего");
            }
            db.SaveChanges();
        }

        private void Summa_Click(object sender, RoutedEventArgs e)
        {
            for (int i = 0; i < IOrderingService.SelectedItems.Count; i++)
            {
                УслугиЗаказа f = IOrderingService.SelectedItems[i] as УслугиЗаказа;
                for (int j = 0; j < IOrder.SelectedItems.Count; j++)
                {

                    Заказы f2 = IOrder.SelectedItems[i] as Заказы;
                    
                        Predoplata.Text = f2.Предоплата.ToString();
                       

                    
                }

            }



        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            //var st = 0;

            //for (int i = 0; i < IOrderingService.SelectedItems.Count; i++)
            //{
            //    УслугиЗаказа f = IOrderingService.SelectedItems[i] as УслугиЗаказа;
            //    for (int j = 0; j < IOrder.SelectedItems.Count; j++)
            //    {

            //        Заказы f2 = IOrder.SelectedItems[i] as Заказы;


            //        if (f.НомерЗаказа == f2.КодЗаказа)
            //        {
            //            st += f.Стоимость.Value;
            //            SummaDetal.Text = st.ToString();
            //            MessageBox.Show(st.ToString());
            //        }






            //    }

            //}
            OrderingService a = new OrderingService();
            var fg =
                from Заказы in IOrder.Items.ToString() where 



            var firstColumnValues =
               from DataGridViewRow row in dataGridView1.Rows
               group row by row.Cells[0].Value into res
               where res.Key != null
               select new { res.Key, Count = res.Count() };
            Dictionary<object, int> result = firstColumnValues.ToDictionary(arg => arg.Key, arg => arg.Count);

            int rent;
            result.TryGetValue("Договор аренды", out rent);
            MessageBox.Show(rent.ToString());
            int abort;
            result.TryGetValue("Отказ", out abort);
            MessageBox.Show(abort.ToString());




        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
          

            for (int i = 0; i < IOrderingService.SelectedItems.Count; i++)
            {
                УслугиЗаказа f = IOrderingService.SelectedItems[i] as УслугиЗаказа;
                for (int j = 0; j < IOrder.SelectedItems.Count; j++)
                {

                    Заказы f2 = IOrder.SelectedItems[i] as Заказы;

                    ObSumma.Text = (f.Стоимость + f2.Стоимость - f2.Предоплата).ToString() ;



                }

            }

        }
    }
}
